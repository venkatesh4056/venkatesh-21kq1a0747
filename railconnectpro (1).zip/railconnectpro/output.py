Python 3.11.1 (tags/v3.11.1:a7a450f, Dec  6 2022, 19:58:39) [MSC v.1934 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> 
= RESTART: C:\Users\LENOVO\AppData\Local\Programs\Python\Python311\lakshman.py =

Welcome to the Railway Ticket Reservation System!

Available Destinations:
Banglore
Chennai
Hyderabad

Please enter your destination (or type 'exit' to quit): Banglore

Available trains for Banglore (sorted by price):
Train4: Price = 200, Time = 5h 00m, Available Seats = 60

Please enter the train you want to book (e.g., Train1): Train4
Enter the number of seats you want to book on Train4: 6

Booking Successful!
Train: Train4
Destination: Banglore
Price per ticket: 200
Total Price: 1200
Time: 5h 00m
Seats booked: 6
Remaining Seats: 54

Do you want to book another ticket? (yes/no): 
== RESTART: C:/Users/LENOVO/OneDrive/Desktop/railconnectpro/railconnectpro.py ==

Welcome to the Railway Ticket Reservation System!

Available Destinations:
Banglore
Chennai
Hyderabad

